const db = require('../config/db');

exports.getHotels = (req, res) => {
    db.con.query("SELECT * from Hotels" , (err,data) => {
	if (err) console.log(err)
	res.json(data);
})	
};


exports.getHotelDetails = (req, res) => {
	db.con.query("SELECT * from Hotels WHERE hotelID = (?)" , [req.params.id] , (err,data) => {
		if (err) console.log(err);
		res.json(data);
})	
};