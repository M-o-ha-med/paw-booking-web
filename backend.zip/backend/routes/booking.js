const express = require('express');
const router = express.Router();

const { createBooking, confirmBooking , getBooking , deleteBookingByAdmin } = require('../controllers/bookingController');
const { authenticateToken, isAdmin } = require('../middleware/authMiddleware');

router.post('/', authenticateToken, createBooking);
router.patch('/:id/confirm' , confirmBooking);
router.get('/',getBooking);
router.delete('/:id/delete', deleteBookingByAdmin)
router.post('/', authenticateToken, createBooking);
router.patch('/:id/confirm', authenticateToken, isAdmin, confirmBooking);

module.exports = router;
