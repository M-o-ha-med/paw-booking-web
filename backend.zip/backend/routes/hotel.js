const express = require('express');
const router = express.Router();
const { authenticateToken, isAdmin } = require('../middleware/authMiddleware');
const { getHotels, getHotelDetails } = require('../controllers/hotelController');

router.get('/', authenticateToken, getHotels);
router.get('/:id', authenticateToken, getHotelDetails);

module.exports = router;